function scan() {
  document.getElementById('result').textContent = "Scan en cours... Aucun fichier malveillant détecté.";
}

function clean() {
  document.getElementById('result').textContent = "Nettoyage terminé ! Fichiers inutiles supprimés : 12.";
}

function optimize() {
  document.getElementById('result').textContent = "Optimisation réussie ! RAM et batterie améliorées.";
}
