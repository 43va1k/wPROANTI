# WPRO ANTIVIRUS

Une app antivirus Android/iOS/web créée avec Flutter Web.

## Fonctionnalités
- **Scanner de fichiers malveillants**
- **Nettoyage des fichiers inutiles et doublons**
- **Optimisation de la RAM et batterie**

## Structure du projet

```
wpro-antivirus-web/
├── index.html
├── vercel.json
├── style.css
├── script.js
├── README.md
├── assets/
│   └── icon.png
```

## Déploiement sur Vercel ou GitHub Pages

1. Hébergez le dossier sur votre dépôt GitHub
2. Liez-le à Vercel
3. Ajoutez ce fichier `vercel.json` pour éviter les erreurs 404

## Auteurs

- [43va1k](https://github.com/43va1k)

---

*Icône par défaut fournie (assets/icon.png), remplacez-la si besoin !*
